import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "ResultServlet", urlPatterns = {"/result"})
public class ResultServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter pw=null;    
        try{
            pw=resp.getWriter();
            HttpSession ses=req.getSession();
             int right=Integer.parseInt(ses.getAttribute("right").toString());
                        int wrong=Integer.parseInt(ses.getAttribute("wrong").toString());
                        int marks=Integer.parseInt(ses.getAttribute("marks").toString());
                        String test=ses.getAttribute("subject").toString();
                         pw.println("<html><head><style>.header{font-size:18px;font-family:consolas:font-weight:bold;color:black;width:50px;height:auto;text-align:center;padding:20px 0px;border:2px solid black;}.value{font-family:tahoma;font-size:12px;width:30px;height:auto;padding:20px 0px;color:white;text-align:center;border:2px solid black;}</style><title>Result</title></head><body style='background-color:#f4511e;'>");
                         pw.println("<center><div>");
                         pw.println("<table style='width:300px;height:auto;border:2px solid black;border-radius:5px;border-collapse:collapse;'><caption style='color:white;font-family:verdana;font-size:22px;'>Test Result</caption><tr><td class='header'>Subject:</td><td class='value'>"+test+"</td></tr><tr><td class='header'>Marks:</td><td class='value'>"+marks+"</td></tr><tr><td class='header'>Right:</td><td class='value'>"+right+"</td></tr><tr><td class='header'>Wrong:</td><td class='value'>"+wrong+"</td></tr></table>");
                        pw.println("</div></center></body></html>");
            }
            catch(Exception e)
            {}
    }

}
