package com.reuse;
import java.sql.*;
public class DatabaseConnectivity {
    static Statement st;
    static Connection con;
    public static Statement makeConnection()
    {
    try{
    Class.forName("oracle.jdbc.driver.OracleDriver");
    con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","Saksham","9027904442");
    st=con.createStatement();
    }
    catch(Exception e)
    {}
    return st;
    }
    public static void closeConnection(){
    try{
    st.close();
    con.close();
    }
    catch(Exception e)
    {}
    }
}
