import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "TestEngine", urlPatterns = {"/test"})
public class TestEngine extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                    
        PrintWriter pw=null;            
        try{
             pw=resp.getWriter();            
            HttpSession ses=req.getSession();
                        int ques=Integer.parseInt(ses.getAttribute("ques").toString());
                        int right=Integer.parseInt(ses.getAttribute("right").toString());
                        int wrong=Integer.parseInt(ses.getAttribute("wrong").toString());
                        int marks=Integer.parseInt(ses.getAttribute("marks").toString());
                        String test=ses.getAttribute("subject").toString();
                       pw=resp.getWriter();
                       pw.println("<html><head><script src='timer.js'></script><title>Test</title></head><body style='background-color:#428bca;' onload='setInterval(countdown,1000)'>");
                       pw.println("<center><h1>"+test+" Test</h1></center>");
                       pw.println("<header style='font-size:18px;font-family:tahoma;'><span style='color:white;'>Subject: "+test+"</span><span style='color:white;padding:30px;'>Ques:"+ques+"</span><span style='color:white;padding:30px;'>Marks:"+marks+"</span><span style='color:white;padding:30px;'>Right:"+right+"</span><span style='color:white;padding:30px;'>Wrong:"+wrong+"</span><span style='color:white;padding:30px;' id='spn6'></span></header>");
                       Statement st1=makeConnection();
                        pw.println("<div style='margin-top:10px;background-color:white;'>");
                       pw.println("<form action='check' id='frm'>");
                       ResultSet rs=st1.executeQuery("select * from "+test);
                       int index=getRandom();
                       //pw.println(index);
                       ses.setAttribute("index",index);
                       int i=1;
                       while(i<index+1&&rs.next()){
                            i++;}
                       pw.println("<span style='color:#428bca;padding:5px;'>"+rs.getString(1)+"</span><br/>");
                       pw.println("<input type='radio' name='rad' value='A'>"+rs.getString(2)+"<br/>");
                       pw.println("<input type='radio' name='rad' value='B'>"+rs.getString(3)+"<br/>");
                       pw.println("<input type='radio' name='rad' value='C'>"+rs.getString(4)+"<br/>");
                       pw.println("<input type='radio' name='rad' value='D'>"+rs.getString(5)+"<br/>");
                       pw.println("<input type='submit' name='sbt' value='Submit' style='background-color:#428bac;padding:5px 10px;border-radius:3px;border:1px solid #428abc;margin-left:5px;color:white;font-family:tahoma;font-size:12px;'>");
                       pw.println("<input type='reset' name='rst' value='Clear' style='background-color:#428bac;padding:5px 10px;border-radius:3px;border:1px solid #428abc;margin-left:5px;color:white;font-family:tahoma;font-size:12px;'>");
                       pw.println("</form>");
                       pw.println("</div></body></html>");
                       closeConnection();
                       rs.close();
                    }
                    catch(Exception e)
                    {pw.println("Exception: "+e);}
                    
    }
     static Statement st;
     static Connection con;
    static Statement makeConnection(){
        
        try{   Class.forName("oracle.jdbc.driver.OracleDriver");
                con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","Saksham","9027904442");
                st=con.createStatement();
                        }
       catch(Exception e)
       {}
        return st;
    }
    static void closeConnection(){
            try{
            st.close();
            con.close();
            }
            catch(Exception e)
            {}
    }
    static int getRandom()
    {
        int index=(int)((Math.random()*10)+1);
        return index;
    }

}
