import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static com.reuse.DatabaseConnectivity.*;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.http.HttpSession;
@WebServlet(name = "VerifyServlet", urlPatterns = {"/verify"})
public class VerifyServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       PrintWriter pw=resp.getWriter();
        try{
        String email=req.getParameter("email");
        String id=req.getParameter("id");
        Statement st=makeConnection();
        //pw.println("hello world");
        String timeq="select extract(day from(sysdate-signuptime))*24*60+extract(hour from(sysdate-signuptime))*60+extract(minute from(sysdate-signuptime)) from studentreg where email='"+email+"'";
        ResultSet rs=st.executeQuery(timeq);
        rs.next();
        int time=rs.getInt(1);
        String verifyq="select verified from studentreg where email='"+email+"'and id='"+id+"'";
        rs=st.executeQuery(verifyq);
        rs.next();
        String verify=rs.getString(1);
        //pw.println(verify);
       // pw.println(time);
        if(verify.equals("N")){
        if(time<15)
        {
         String query="update studentreg set verified='Y' where email='"+email+"' and id='"+id+"'";
          int n=st.executeUpdate(query);
          if(n==0){
              pw.println("<html><center><span style='color:red;'>The link you entered is Invalid,please enter valid link</span></center></html>");}
          else{
               HttpSession ses=req.getSession();
          String contact=ses.getAttribute("contact").toString();
          String password=getPassword();
          //pw.println(contact+" "+password);
          st.executeUpdate("update studentreg set password='"+password+"' where id='"+id+"'");
          String strurl="http://api.mVaayoo.com/mvaayooapi/MessageCompose?user=amanaggarawal71@gmail.com:902790&senderID=TEST%20SMS&receipientno="+contact+"&dcs=0&msgtxt=The_password_for_your_account_is_"+password+"&state=4"; 
          URL url=new URL(strurl);
          try{
          url.openStream(); }
          catch(Exception e1)
          {}
          resp.sendRedirect("Login.html");
              }
        }
        else{
        pw.println("<html><center><span style='color:red;'>The link you entered is Expired,Try again</span></center></html>");
        }
        }
        else{
         pw.println("<html><center><span style='color:red;'>The link you entered is already verifed,Please login into your account</span></center></html>");
        }
        closeConnection();
        }
        catch(Exception e)
        {}
    }
    public static String getPassword()
    {
        String pass="";
        for(int i=0;i<4;i++)
        {
            int ch=(int)(10*Math.random());
            pass+=ch;
        }
        return pass;
    }
}