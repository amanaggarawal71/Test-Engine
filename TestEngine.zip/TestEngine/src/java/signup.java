import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.Connection;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.reuse.DatabaseConnectivity;
import java.net.InetAddress;
import javax.servlet.http.HttpSession;
@WebServlet(name = "signup", urlPatterns = {"/signup123"})
public class signup extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       PrintWriter pw=resp.getWriter();
        try{
            String fname=req.getParameter("txt1");
            String lname=req.getParameter("txt2");
            String email=req.getParameter("txt3");
            String contact=req.getParameter("txt4");
            String gender=req.getParameter("gen");
            String id=getRandomId();
            Statement st=DatabaseConnectivity.makeConnection();
        st.executeUpdate("insert into STUDENTREG(fname,lname,email,contact,gender,signuptime,verified,id) values('"+fname+"','"+lname+"','"+email+"',"+contact+",'"+gender+"',sysdate,'N','"+id+"')");
        //pw.println("Values saved");
        DatabaseConnectivity.closeConnection();
        sendEmail(email,id);
        HttpSession ses=req.getSession();
        ses.setAttribute("contact",contact);
        resp.sendRedirect("Confirmation.html");
        }
        catch(Exception e)
        {pw.println("Exception "+e);}
    }
    public static String getRandomId()
    {
        String res="";
        String req="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        int len=req.length();
        for(int i=0;i<20;i++)
        {
            int n=(int)(len*Math.random());
            char ch=req.charAt(n);
            res+=ch;
        }
        return res;
    }
    public void sendEmail(String email,String id)
    {
       try{
        String user="amanaggarawal70";   
       String password="9027904442";
       String sender="amanaggarawal70@gmail.com";
       String host="smtp.gmail.com";
       String port="465";
       Properties props=new Properties();
       props.put("mail.smtp.user",user);
      props.put("mail.smtp.password",password);
      props.put("mail.smtp.host",host);
      props.put("mail.smtp.port",port);
      props.put("mail.smtps.auth",true);
      Session ses=Session.getDefaultInstance(props);
      MimeMessage mime=new MimeMessage(ses);
      InternetAddress from=new InternetAddress(sender);
      InternetAddress to=new InternetAddress(email);
      mime.setSender(from);
      mime.setRecipient(Message.RecipientType.TO, to);
       mime.setSubject("Confirmation Email");
       InetAddress address=InetAddress.getLocalHost();
       String ip=address.getHostAddress();
       mime.setContent("Dear Sir/Mam,<br><br>Greetings from Portal!!!<br><br> This is confirmation mail from student portal, Please click on below link and verify yourself<br>http://"+ip+":47719/TestEngine/verify?email="+email+"&id="+id,"text/html");
       Transport trans=ses.getTransport("smtps");
       trans.connect(host,user,password);
       trans.sendMessage(mime,mime.getAllRecipients());}
       catch(Exception e)
       {}
    }
}

    