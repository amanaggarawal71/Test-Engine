import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "ParamServlet", urlPatterns = {"/param"})
public class ParamServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int ques=1,right=0,wrong=0,marks=0;
        String subject=req.getParameter("image");
        HttpSession ses=req.getSession();
        ses.setAttribute("ques",ques);
        ses.setAttribute("right",right);
        ses.setAttribute("wrong",wrong);
        ses.setAttribute("marks",marks);
        ses.setAttribute("subject",subject);
        resp.sendRedirect("test");
        
    }
}
