import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "CheckServlet", urlPatterns = {"/check"})
public class CheckServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
            PrintWriter pw=resp.getWriter();
            HttpSession ses=req.getSession();
            int ques=Integer.parseInt(ses.getAttribute("ques").toString());
            ques+=1;
            int marks=Integer.parseInt(ses.getAttribute("marks").toString());
                int right=Integer.parseInt(ses.getAttribute("right").toString());
                  int wrong=Integer.parseInt(ses.getAttribute("wrong").toString());
                   String test=ses.getAttribute("subject").toString();
                  String option=req.getParameter("rad");
                  if(option!=null){
                  int index=Integer.parseInt(ses.getAttribute("index").toString());
                  Statement st=makeConnection();
                  ResultSet rs=st.executeQuery("select * from "+test);
                  int i=1;
                  while(i<index+1&&rs.next()){
                  i++;
                  }
                  String correct=rs.getString(6);
                  if(option.equals(correct))
                  {
                        marks+=4;
                        right+=1;
                  }
                  else{
                      marks-=1;
                       wrong+=1;
                  }
                  //pw.println(wrong);
                 
                  closeConnection();
                  rs.close();}
                  ses.setAttribute("ques",ques);
        ses.setAttribute("right",right);
        ses.setAttribute("wrong",wrong);
        ses.setAttribute("marks",marks);
                if(ques<6){
                 resp.sendRedirect("test");}
                else{
                resp.sendRedirect("result");}
         }
        catch(Exception e)
        {}
    }
    static Statement st;
     static Connection con;
    static Statement makeConnection(){
        
        try{   Class.forName("oracle.jdbc.driver.OracleDriver");
                con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","Saksham","9027904442");
                st=con.createStatement();
                        }
       catch(Exception e)
       {}
        return st;
    }
    static void closeConnection(){
            try{
            st.close();
            con.close();
            }
            catch(Exception e)
            {}
    }
}
