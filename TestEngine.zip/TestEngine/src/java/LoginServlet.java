import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;
@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       
        PrintWriter pw=null;
        try{ 
        pw=resp.getWriter();
            String email=req.getParameter("txt1");
        String password=req.getParameter("txt2");
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","Saksham","9027904442");
        PreparedStatement pst=con.prepareStatement("select * from studentreg where email=? and password=?");
        pst.setString(1,email);
        pst.setString(2,password);
        ResultSet rs=pst.executeQuery();
        if(rs.next())
        {
            String name=rs.getString(1)+" "+rs.getString(2);
            HttpSession ses=req.getSession();
            ses.setAttribute("user",name);
            ses.setMaxInactiveInterval(60);
            resp.sendRedirect("UserPge.jsp");
        }
        else{
        pw.println("Not a valid user,Please try again");
        }
        rs.close();
        con.close();
        pst.close();
        }
        catch(Exception e)
        {pw.println("Not a valid link");}
    }
}
