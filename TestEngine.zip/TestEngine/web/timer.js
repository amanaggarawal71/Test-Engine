var c=60;
function countdown(){
    if(c>-1){
        if(c==0){
            var form=document.getElementById('frm');
            form.reset();
            form.submit();
        }
        var spn=document.getElementById('spn6');
        if(c>10){
        spn.style.color="green";}
        else{spn.style.color="red";}
        spn.innerHTML="Timer- 00:"+c;
        c=c-1;
    }
   }